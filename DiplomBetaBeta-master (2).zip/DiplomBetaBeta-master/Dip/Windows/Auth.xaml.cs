﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Dip.Windows
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Window
    {
        public Auth()
        {
            InitializeComponent();
        }

        private void btAauth_Click(object sender, RoutedEventArgs e)
        {
            //if (EfModel.Init().Workers.Any(p => p.Login == tbLogin.Text && p.Password == tbPass.Text))
            //{
            //    Hide();
            //}
            MessageBox.Show("gdf");
            new MainWindow().Show();
        }
    }
}
